package br.com.isantos.exame.servlets;

import br.com.isantos.exame.domain.Aluno;
import br.com.isantos.exame.domain.Materia;
import br.com.isantos.exame.domain.Nota;
import br.com.isantos.exame.repository.AlunoRepository;
import br.com.isantos.exame.repository.MateriaRepository;
import br.com.isantos.exame.repository.NotaRepository;
import br.com.isantos.exame.service.ConnectionFactory;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

/**
 * Created by felipe on 15/06/16.
 */
@WebServlet("/nota/lancar")
public class LancarNotaServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        List<Aluno> alunos;
        List<Materia> materias;
        try (Connection conn = ConnectionFactory.getConnection()) {
            alunos = new AlunoRepository(conn).findAll();
            materias = new MateriaRepository(conn).findAll();
        } catch (SQLException e) {
            throw new ServletException("Erro ao obter dados", e);
        }

        req.setAttribute("alunos", alunos);
        req.setAttribute("materias", materias);
        req.getRequestDispatcher("/nota/lancar.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Integer alunoParameter   = Integer.parseInt(req.getParameter("aluno"));
        Integer materiaParameter = Integer.parseInt(req.getParameter("materia"));
        Integer notaParameter    = Integer.parseInt(req.getParameter("notas"));

        Nota nota = new Nota();
        nota.getAluno().setId(alunoParameter);
        nota.getMateria().setId(materiaParameter);
        nota.setNota(notaParameter);

        try (Connection conn = ConnectionFactory.getConnection()) {
            NotaRepository notaRepository = new NotaRepository(conn);
            notaRepository.save(nota);
        } catch (SQLException e) {
            throw new ServletException("Erro ao cadastrar nota " + notaParameter + " na materia " + materiaParameter + " para o aluno " + alunoParameter, e);
        }

        resp.sendRedirect(req.getContextPath() + "/nota/listar");
    }
}
