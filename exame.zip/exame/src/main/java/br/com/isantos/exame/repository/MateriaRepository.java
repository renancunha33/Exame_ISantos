package br.com.isantos.exame.repository;

import br.com.isantos.exame.domain.Materia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Felipe Martins
 */
public class MateriaRepository {

    private Connection conn;

    public MateriaRepository(Connection conn) {
        this.conn = conn;
    }

    public void save(Materia aluno) throws SQLException {
        String comando = "INSERT INTO materia (nome) VALUES (?)";

        try (PreparedStatement ps = conn.prepareStatement(comando)) {
            ps.setString(1, aluno.getNome());
            ps.executeUpdate();
        }
    }

    public List<Materia> findAll() throws SQLException {

        List<Materia> materias = new ArrayList<>();
        Materia materia;

        try (ResultSet resultSet = conn.createStatement().executeQuery("SELECT * FROM materias")) {
            while (resultSet.next()) {
                materia = new Materia();
                materia.setId(resultSet.getInt("codigo"));
                materia.setNome(resultSet.getString("nome"));

                materias.add(materia);
            }
        }

        return materias;
    }

}
