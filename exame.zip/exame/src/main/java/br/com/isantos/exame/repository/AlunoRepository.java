package br.com.isantos.exame.repository;

import br.com.isantos.exame.domain.Aluno;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by felipe on 14/06/16.
 */
public class AlunoRepository {

    private Connection conn;

    public AlunoRepository(Connection conn) {

        this.conn = conn;
    }

    public void save(Aluno aluno) throws SQLException {
        String comando = "INSERT INTO aluno (nome) VALUES (?)";

        try (PreparedStatement ps = conn.prepareStatement(comando)) {
            ps.setString(1, aluno.getNome());
            ps.executeUpdate();
        }
    }

    public List<Aluno> findAll() throws SQLException {

        List<Aluno> alunos = new ArrayList<>();
        Aluno aluno;

        try (ResultSet resultSet = conn.createStatement().executeQuery("SELECT * FROM aluno")) {
            while (resultSet.next()) {
                aluno = new Aluno();
                aluno.setId(resultSet.getInt("id"));
                aluno.setNome(resultSet.getString("nome"));

                alunos.add(aluno);
            }
        }

        return alunos;
    }
}
