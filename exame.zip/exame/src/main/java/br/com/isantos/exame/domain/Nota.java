package br.com.isantos.exame.domain;

/**
 * Created by felipe on 14/06/16.
 */
public class Nota {

    private Aluno aluno;
    private Materia materia;

    private Integer nota;

    public Aluno getAluno() {
        return aluno;
    }

    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    public Materia getMateria() {
        return materia;
    }

    public void setMateria(Materia materia) {
        this.materia = materia;
    }

    public Integer getNota() {
        return nota;
    }

    public void setNota(Integer nota) {
        this.nota = nota;
    }
}
