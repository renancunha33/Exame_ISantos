package br.com.isantos.exame.repository;

import br.com.isantos.exame.domain.Aluno;
import br.com.isantos.exame.domain.Materia;
import br.com.isantos.exame.domain.Nota;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author felipe
 */
public class NotaRepository {
    private Connection conn;

    public NotaRepository(Connection conn) {
        this.conn = conn;
    }

    public void save(Nota nota) throws SQLException {
        String comando = "INSERT INTO nota(aluno, materia, nota) VALUES(?,?,?)";

        try (PreparedStatement ps = conn.prepareStatement(comando)) {
            ps.setInt(1, nota.getAluno().getId());
            ps.setInt(2, nota.getMateria().getId());
            ps.setInt(3, nota.getNota());
            ps.executeUpdate();
        }
    }


    public List<Nota> findAllByAlunoAndMateria(Integer codigoAluno, Integer codigoMateria) throws SQLException {
        List<Nota> notas = new ArrayList<>();
        Nota nota;

        String comando =
                 "SELECT notas.materia AS codigo_materia, " +
                        "materia.nome  as nome_materia, " +
                        "notas.aluno   as codigo_aluno, " +
                        "aluno.nome    as nome_aluno " +
                   "FROM notas " +
                   "JOIN aluno ON notas.aluno = aluno.codigo " +
                   "JOIN materia ON materia.codigo = notas.materia " +
                  "WHERE aluno = ? AND materia = ? ";

        try (PreparedStatement ps = conn.prepareStatement(comando)) {
            ps.setInt(1, codigoAluno);
            ps.setInt(2, codigoMateria);

            try (ResultSet resultSet = ps.executeQuery()) {
                while (resultSet.next()) {
                    nota = new Nota();

                    nota.getAluno().setId(resultSet.getInt("codigo_aluno"));
                    nota.getAluno().setNome(resultSet.getString("nome_aluno"));

                    nota.getMateria().setId(resultSet.getInt("codigo_materia"));
                    nota.getMateria().setNome(resultSet.getString("nome_materia"));

                    nota.setNota(resultSet.getInt("nota"));

                    notas.add(nota);
                }
            }
        }
        return notas;
    }
}
